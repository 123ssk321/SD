package sd2122.aula3.server;

import java.net.InetAddress;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.glassfish.jersey.jdkhttp.JdkHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import sd2122.aula3.api.util.Discovery;
import sd2122.aula3.server.resources.UsersResource;
import sd2122.aula3.server.util.CustomLoggingFilter;
import sd2122.aula3.server.util.GenericExceptionMapper;
import util.Debug;

public class UsersServer {

	private static Logger Log = Logger.getLogger(UsersServer.class.getName());

	static {
		System.setProperty("java.net.preferIPv4Stack", "true");
	}
	
	public static final int PORT = 8080;
	public static final String SERVICE = "UsersService";
	private static final String SERVER_URI_FMT = "http://%s:%s/rest";
	
	public static void main(String[] args) {
		try {
			Debug.setLogLevel( Level.INFO, Debug.SD2122 );
			
		ResourceConfig config = new ResourceConfig();
		config.register(UsersResource.class);
		config.register(CustomLoggingFilter.class);
		config.register(GenericExceptionMapper.class);
		
		String ip = InetAddress.getLocalHost().getHostAddress();
		String serverURI = String.format(SERVER_URI_FMT, ip, PORT);
		JdkHttpServerFactory.createHttpServer( URI.create(serverURI), config);
		Discovery discovery = new Discovery(Discovery.DISCOVERY_ADDR, SERVICE, serverURI);

		Log.info(String.format("%s Server ready @ %s\n",  SERVICE, serverURI));
		discovery.announce(SERVICE, serverURI);
		//More code can be executed here...
		} catch( Exception e) {
			Log.severe(e.getMessage());
		}
	}	
}
